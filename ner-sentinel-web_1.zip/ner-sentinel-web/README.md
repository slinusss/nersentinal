# NER Sentinel — Next.js frontend (JanReport UI system)

This replaces the old single-file `index.html` / `app.js` prototype UI with a
proper Next.js app, using JanReport's design system (shadcn/ui components,
Tailwind v4 tokens) and role-based route-group routing pattern. **The FastAPI
backend in `NER-Sentinel/backend` is untouched** — this is a new frontend
that talks to it over HTTP; nothing on the API side needed to change.

## What's built

- **Design system**: `components/ui/*` (Button, Card, Table, Tabs, Dialog,
  Select, Badge, Input, Textarea, etc.) copied from JanReport, Tailwind v4 +
  shadcn tokens in `app/globals.css`.
- **Auth**: `/login` posts to `/api/session/login`, which calls FastAPI's
  `/api/auth/login` and stores the returned bearer token in an **httpOnly**
  cookie (`ner_session`). `lib/auth.ts#getCurrentProfile()` resolves it
  server-side against `/api/me` — same pattern JanReport uses. The token
  never reaches client-side JS.
- **Routing**: three route groups — `app/(citizen)`, `app/(official)`,
  `app/(admin)` — each with a `layout.tsx` doing a server-side role check and
  redirect. Every nav destination is a real URL with working back/forward,
  refresh and deep links, replacing the legacy `showView('map')` JS hack.
- **Write actions without exposing the token**: `app/api/proxy/[...path]`
  is a generic authenticated forwarder — client components call
  `fetch("/api/proxy/reports/123/assign", …)` and the route handler attaches
  the bearer token server-side before forwarding to FastAPI. Used for
  assigning reports, starting investigations, saving field decisions,
  evidence photo upload (multipart), submitting citizen reports, and route
  planning.
- **Shared Leaflet map** (`components/map/risk-map.tsx` +
  `risk-map-client.tsx` dynamic/SSR-safe wrapper), reused by the admin map
  and the citizen safe-route planner.

### Admin (`/dashboard`, `/map`, `/reports`, `/investigations`, `/incidents`,
`/intelligence`, `/analytics`, `/audit`)
All wired to live FastAPI data: dashboard counts, full GIS risk map with
critical-corridor cards, reports table with an **Assign to official** dialog,
a three-column investigation board, incidents table, AI feature-contribution
breakdown for the highest-risk corridor, analytics (by state/month/lifecycle),
and the audit log.

### Citizen (`/report`, `/my-reports`, `/map`, `/alerts`)
Hazard report form (posts to `/api/reports`, shows the AI-assigned priority
and risk score back), My reports tracker, a safe-route planner (origin/
destination → `/api/routes`, draws the returned route geometry on the map,
lets you compare alternatives), and an alerts/notifications feed.

### Field official (`/assignments`, `/investigation`, `/evidence`)
Assignments list → click through to `/investigation?report=ID` to start an
investigation and record the field decision (outcome + road condition) →
"Add evidence" link to `/evidence?investigation=ID` for the real multipart
photo upload, which shows the AI hazard classification back after upload.

## How to run it

**1. Start the existing FastAPI backend** exactly as before, from the
`NER-Sentinel` folder:

```powershell
$env:UV_CACHE_DIR = "$PWD\.uv-cache"
$env:UV_PYTHON_INSTALL_DIR = "$PWD\.uv-python"
uv sync
uv run uvicorn backend.app.main:app --host 127.0.0.1 --port 8000
```

**2. Start this frontend** in a second terminal, from this folder:

```bash
npm install
cp .env.local.example .env.local   # only if your API isn't on 127.0.0.1:8000
npm run dev
```

**3. Open http://localhost:3000** — you'll land on `/login`. Use any of the
three demo accounts (password `Demo@123` for all):

| Role | Email | Lands on |
| --- | --- | --- |
| Citizen | citizen@nersentinel.in | `/report` |
| Field official | officer@nersentinel.in | `/assignments` |
| Administrator | admin@nersentinel.in | `/dashboard` |

Click a demo-account button on the login screen to sign in instantly, or
type credentials with a role selected above the form.

**Demo walkthrough** (mirrors the original scenario):
1. Sign in as **Citizen**, submit a hazard report on `/report`.
2. Sign out, sign in as **Administrator**, open `/reports`, click **Assign →**
   on the new report and pick a field official.
3. Sign out, sign in as that **Field official**, open `/assignments`, click
   the report, **Start investigation**, then **Add evidence** to upload a
   photo (any JPEG/PNG works — it'll get an AI or mock classification back),
   then go back and save a field decision (e.g. VERIFIED / ROAD BLOCKED).
4. Sign back in as **Administrator** — `/incidents` now shows the confirmed
   incident, `/audit` shows the trail.
5. Sign in as **Citizen**, go to `/map`, plan a route through the affected
   corridor — the planner returns a safer alternative.

> This sandbox has no network access, so `npm install` has not been run and
> nothing here has been executed against a live Next.js dev server or type-
> checked with the project's real dependencies. I did run a best-effort
> `tsc` syntax pass against all `.ts`/`.tsx` files with a minimal config (no
> installed types, so it only catches real syntax errors, not type errors)
> and it came back clean. Please run `npm install && npm run dev` as your
> first step and tell me about anything that comes up — most likely small
> version-mismatch issues in `package.json`, not structural problems.

## What's intentionally left for you (or a next round)

- **`GET /api/officials`** doesn't exist on the backend yet, so the admin
  "Assign to official" dialog uses a hardcoded list of the three officials
  seeded in `backend/app/database.py`. Add that endpoint and swap
  `KNOWN_OFFICIALS` in `lib/api.ts` for a real fetch when you get to it.
- **Citizen report photo upload**: the backend's photo-upload + AI
  classification endpoint is currently official-only
  (`/api/investigations/{id}/evidence/upload`); the citizen report form only
  submits text fields. Wiring a citizen-side photo upload means either a new
  backend endpoint or reusing this one at report-creation time.
- **Realtime**: everything here is fetched per page-load; there's no
  polling/websocket for live updates (e.g. a new critical-risk alert banner).
  `/api/notifications` exists and is used on the citizen alerts page as a
  one-time fetch — polling it on an interval, or adding an SSE/websocket
  endpoint, is the natural next step.
- **Retiring the legacy SPA**: `index.html`, `app.js`, and the `*.css` files
  in the `NER-Sentinel` root are unused by this frontend but still present
  and still served by FastAPI's `/`, `/admin`, `/mobile/citizen`,
  `/mobile/official` routes. Once you're happy with parity, either delete
  those routes/files and reverse-proxy `/` to this Next.js app (e.g. behind
  nginx, or `next start` on the same port in production), or just leave the
  old prototype reachable at a different port for reference — your call.
