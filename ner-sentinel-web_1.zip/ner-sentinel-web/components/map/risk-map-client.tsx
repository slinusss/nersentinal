"use client";

import dynamic from "next/dynamic";

export const RiskMap = dynamic(() => import("./risk-map").then((m) => m.RiskMap), {
  ssr: false,
  loading: () => (
    <div className="flex h-[420px] items-center justify-center rounded-lg border border-border bg-muted/30 text-sm text-muted-foreground">
      Loading map…
    </div>
  ),
});

const RISK_COLORS: Record<string, string> = {
  LOW: "#22c55e",
  HIGH: "#f97316",
  CRITICAL: "#ef4444",
  BLOCKED: "#7f1d1d",
};

export function RiskLegend() {
  return (
    <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
      {Object.entries(RISK_COLORS).map(([key, color]) => (
        <span key={key} className="flex items-center gap-1.5">
          <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ backgroundColor: color }} />
          {key}
        </span>
      ))}
    </div>
  );
}
