"use client";

import "leaflet/dist/leaflet.css";
import { MapContainer, TileLayer, CircleMarker, Popup, Polyline } from "react-leaflet";
import type { RoadSegment, Incident } from "@/lib/api";

const RISK_COLORS: Record<string, string> = {
  LOW: "#22c55e",
  MODERATE: "#eab308",
  ELEVATED: "#eab308",
  HIGH: "#f97316",
  CRITICAL: "#ef4444",
  BLOCKED: "#7f1d1d",
};

function colorFor(segment: RoadSegment): string {
  if (segment.is_blocked) return RISK_COLORS.BLOCKED;
  return RISK_COLORS[segment.risk?.category ?? "LOW"] ?? RISK_COLORS.LOW;
}

export function RiskMap({
  tileUrl,
  attribution,
  segments,
  incidents = [],
  routePath,
  height = 420,
  center = [25.6, 92.5],
  zoom = 6,
}: {
  tileUrl: string;
  attribution: string;
  segments: RoadSegment[];
  incidents?: Incident[];
  routePath?: [number, number][];
  height?: number;
  center?: [number, number];
  zoom?: number;
}) {
  return (
    <div style={{ height }} className="overflow-hidden rounded-lg border border-border">
      <MapContainer center={center} zoom={zoom} style={{ height: "100%", width: "100%" }} scrollWheelZoom={false}>
        <TileLayer url={tileUrl} attribution={attribution} />
        {segments.map((segment) => (
          <CircleMarker
            key={segment.id}
            center={[segment.latitude, segment.longitude]}
            radius={9}
            pathOptions={{ color: colorFor(segment), fillColor: colorFor(segment), fillOpacity: 0.85 }}
          >
            <Popup>
              <div className="space-y-1 text-sm">
                <p className="font-semibold">{segment.name}</p>
                <p className="text-muted-foreground">
                  {segment.district}, {segment.state}
                </p>
                <p>
                  Risk <b>{segment.risk?.score ?? "—"}</b> · {segment.is_blocked ? "BLOCKED" : segment.risk?.category}
                </p>
                <p className="text-xs text-muted-foreground">Road: {segment.road_condition}</p>
              </div>
            </Popup>
          </CircleMarker>
        ))}
        {incidents.map((incident) =>
          incident.location ? null : null
        )}
        {routePath && routePath.length > 1 && (
          <Polyline positions={routePath} pathOptions={{ color: "#2563eb", weight: 4 }} />
        )}
      </MapContainer>
    </div>
  );
}

export function RiskLegend() {
  return (
    <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
      {Object.entries(RISK_COLORS)
        .filter(([key]) => key !== "MODERATE")
        .map(([key, color]) => (
          <span key={key} className="flex items-center gap-1.5">
            <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ backgroundColor: color }} />
            {key}
          </span>
        ))}
    </div>
  );
}
