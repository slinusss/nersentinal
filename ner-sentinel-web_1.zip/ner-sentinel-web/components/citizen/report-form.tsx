"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const SEVERITIES = ["LOW", "MEDIUM", "HIGH", "CRITICAL"] as const;

export function ReportForm() {
  const router = useRouter();
  const [form, setForm] = useState({
    type: "",
    description: "",
    state: "",
    district: "",
    location: "",
    severity: "MEDIUM" as (typeof SEVERITIES)[number],
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{ id: string; priority: string; risk_score: number } | null>(null);

  function set<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/proxy/reports", { method: "POST", body: JSON.stringify(form) });
      const data = await res.json();
      if (!res.ok) {
        setError(data.detail ?? "Could not submit the report.");
        return;
      }
      setResult(data);
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  if (result) {
    return (
      <div className="space-y-3 rounded-lg border border-border p-4">
        <p className="font-semibold">Report {result.id} submitted</p>
        <p className="text-sm text-muted-foreground">
          Priority <b>{result.priority}</b> · AI risk score <b>{result.risk_score}</b>. Track it on the
          My reports page.
        </p>
        <Button variant="outline" size="sm" onClick={() => setResult(null)}>
          Submit another report
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <div className="space-y-1.5">
        <Label htmlFor="type">Hazard type</Label>
        <Input id="type" value={form.type} onChange={(e) => set("type", e.target.value)} placeholder="e.g. Road blockage" required minLength={3} />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="description">Description</Label>
        <Textarea id="description" value={form.description} onChange={(e) => set("description", e.target.value)} required minLength={5} />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-1.5">
          <Label htmlFor="state">State</Label>
          <Input id="state" value={form.state} onChange={(e) => set("state", e.target.value)} required />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="district">District</Label>
          <Input id="district" value={form.district} onChange={(e) => set("district", e.target.value)} required />
        </div>
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="location">Location description</Label>
        <Input id="location" value={form.location} onChange={(e) => set("location", e.target.value)} required />
      </div>
      <div className="space-y-1.5">
        <Label>Severity</Label>
        <Select value={form.severity} onValueChange={(v) => set("severity", v as (typeof SEVERITIES)[number])}>
          <SelectTrigger className="w-full">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {SEVERITIES.map((s) => (
              <SelectItem key={s} value={s}>
                {s}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      {error && <p className="text-sm text-destructive">{error}</p>}
      <Button type="submit" disabled={loading} className="w-full">
        {loading ? "Submitting…" : "Submit report"}
      </Button>
      <p className="text-xs text-muted-foreground">
        Photo evidence upload isn&apos;t wired up on the citizen form yet — the backend endpoint
        for it lives under field-official evidence upload; extending it to citizen reports is
        listed as follow-up work.
      </p>
    </form>
  );
}
