"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { RiskMap } from "@/components/map/risk-map-client";
import type { RouteOption, RoadSegment } from "@/lib/api";

export function RoutePlanner({
  tileUrl,
  attribution,
}: {
  tileUrl: string;
  attribution: string;
}) {
  const [origin, setOrigin] = useState("Shillong");
  const [destination, setDestination] = useState("Ratacherra");
  const [routes, setRoutes] = useState<RouteOption[] | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [selected, setSelected] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function plan(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const qs = new URLSearchParams({ origin, destination });
      const res = await fetch(`/api/proxy/routes?${qs.toString()}`);
      const data = await res.json();
      if (!res.ok) {
        setError(data.detail ?? "Could not plan a route.");
        return;
      }
      setRoutes(data.routes);
      setMessage(data.message);
      setSelected(0);
    } finally {
      setLoading(false);
    }
  }

  const activeRoute = routes?.[selected];

  return (
    <div className="space-y-4">
      <form onSubmit={plan} className="flex flex-wrap items-end gap-3">
        <div className="space-y-1.5">
          <Label htmlFor="origin">From</Label>
          <Input id="origin" value={origin} onChange={(e) => setOrigin(e.target.value)} />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="destination">To</Label>
          <Input id="destination" value={destination} onChange={(e) => setDestination(e.target.value)} />
        </div>
        <Button type="submit" disabled={loading}>
          {loading ? "Finding routes…" : "Find safe route"}
        </Button>
      </form>

      {error && <p className="text-sm text-destructive">{error}</p>}
      {message && <p className="text-sm font-medium text-amber-600">{message}</p>}

      {routes && (
        <>
          <RiskMap
            tileUrl={tileUrl}
            attribution={attribution}
            segments={[] as RoadSegment[]}
            routePath={activeRoute?.geometry}
            height={360}
            center={activeRoute?.geometry?.[Math.floor((activeRoute.geometry.length ?? 1) / 2)] ?? [25.6, 92.5]}
            zoom={8}
          />
          <div className="grid gap-3 md:grid-cols-3">
            {routes.map((route, i) => (
              <Card
                key={route.label + i}
                className={`cursor-pointer transition-colors ${i === selected ? "border-primary" : ""}`}
                onClick={() => setSelected(i)}
              >
                <CardContent className="space-y-1 p-4 text-sm">
                  <p className="font-semibold">{route.label}</p>
                  <p className="text-muted-foreground">
                    {route.distance_km} km · {route.duration_minutes} min
                  </p>
                  <p>
                    Risk: <b>{route.risk_level}</b>
                    {route.avoids_blockage && " · avoids blockage"}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
