"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export function EvidenceUploadForm({ investigationId }: { investigationId: string }) {
  const [file, setFile] = useState<File | null>(null);
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{
    url: string;
    ai_classification: { category: string; severity: string; summary: string; data_mode: string };
  } | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!file) {
      setError("Choose a photo first.");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const form = new FormData();
      form.append("photo", file);
      form.append("notes", notes);
      const res = await fetch(`/api/proxy/investigations/${investigationId}/evidence/upload`, {
        method: "POST",
        body: form,
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.detail ?? "Upload failed.");
        return;
      }
      setResult(data);
    } finally {
      setLoading(false);
    }
  }

  if (result) {
    return (
      <div className="space-y-2 rounded-lg border border-border p-4 text-sm">
        <p className="font-semibold">Evidence uploaded</p>
        <p>
          AI classification: <b>{result.ai_classification.category}</b> ·{" "}
          {result.ai_classification.severity} ({result.ai_classification.data_mode})
        </p>
        <p className="text-muted-foreground">{result.ai_classification.summary}</p>
        <Button variant="outline" size="sm" onClick={() => setResult(null)}>
          Upload another photo
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <div className="space-y-1.5">
        <Label htmlFor="photo">Photo (JPEG/PNG/WEBP/HEIC, max 8MB)</Label>
        <Input
          id="photo"
          type="file"
          accept="image/jpeg,image/png,image/webp,image/heic"
          onChange={(e) => setFile(e.target.files?.[0] ?? null)}
          required
        />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="notes">Notes</Label>
        <Textarea id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} />
      </div>
      {error && <p className="text-sm text-destructive">{error}</p>}
      <Button type="submit" disabled={loading}>
        {loading ? "Uploading…" : "Upload evidence"}
      </Button>
    </form>
  );
}
