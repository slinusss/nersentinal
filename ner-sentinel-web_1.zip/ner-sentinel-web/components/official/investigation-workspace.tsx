"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { Report, Investigation } from "@/lib/api";

const OUTCOMES = ["VERIFIED", "PARTIALLY VERIFIED", "REJECTED", "NEEDS FURTHER INVESTIGATION"] as const;
const ROAD_CONDITIONS = ["CLEAR", "WET", "CAUTION", "PARTIALLY BLOCKED", "ROAD BLOCKED"] as const;

export function InvestigationWorkspace({
  report,
  investigation,
}: {
  report: Report;
  investigation: Investigation | null;
}) {
  const router = useRouter();
  const [notes, setNotes] = useState(investigation?.notes ?? "");
  const [outcome, setOutcome] = useState<(typeof OUTCOMES)[number]>("VERIFIED");
  const [roadCondition, setRoadCondition] = useState<(typeof ROAD_CONDITIONS)[number]>("CAUTION");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function startInvestigation() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/proxy/reports/${report.id}/investigation/start`, {
        method: "POST",
        body: JSON.stringify({ notes }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.detail ?? "Could not start the investigation.");
        return;
      }
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  async function saveDecision() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/proxy/reports/${report.id}/verify`, {
        method: "POST",
        body: JSON.stringify({ outcome, notes, road_condition: roadCondition }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.detail ?? "Could not save the field decision.");
        return;
      }
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="rounded-lg border border-border p-4 text-sm">
        <p className="font-semibold">{report.id} · {report.type}</p>
        <p className="text-muted-foreground">{report.description}</p>
        <p className="mt-1 text-muted-foreground">
          {report.district}, {report.state} · Risk {report.risk_score} · Status {report.status}
        </p>
      </div>

      {!investigation ? (
        <div className="space-y-3">
          <Label htmlFor="start-notes">Investigation notes</Label>
          <Textarea id="start-notes" value={notes} onChange={(e) => setNotes(e.target.value)} />
          <Button onClick={startInvestigation} disabled={loading}>
            {loading ? "Starting…" : "Start investigation"}
          </Button>
        </div>
      ) : (
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Investigation {investigation.id} · status {investigation.status}
          </p>
          <Link
            href={`/evidence?investigation=${investigation.id}`}
            className="inline-block text-sm font-medium text-primary underline underline-offset-4"
          >
            Add evidence →
          </Link>

          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Field decision</Label>
              <Select value={outcome} onValueChange={(v) => setOutcome(v as (typeof OUTCOMES)[number])}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {OUTCOMES.map((o) => (
                    <SelectItem key={o} value={o}>
                      {o}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Road condition</Label>
              <Select value={roadCondition} onValueChange={(v) => setRoadCondition(v as (typeof ROAD_CONDITIONS)[number])}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ROAD_CONDITIONS.map((c) => (
                    <SelectItem key={c} value={c}>
                      {c}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="decision-notes">Notes</Label>
              <Textarea id="decision-notes" value={notes} onChange={(e) => setNotes(e.target.value)} />
            </div>
            <Button onClick={saveDecision} disabled={loading}>
              {loading ? "Saving…" : "Save field decision"}
            </Button>
          </div>
        </div>
      )}

      {error && <p className="text-sm text-destructive">{error}</p>}
    </div>
  );
}
