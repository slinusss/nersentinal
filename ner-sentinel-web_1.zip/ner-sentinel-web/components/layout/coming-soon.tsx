import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

export function ComingSoon({
  title,
  description,
  endpoint,
}: {
  title: string;
  description: string;
  endpoint?: string;
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="text-sm text-muted-foreground">
        Routing and access control for this page are live — this is the
        placeholder content to be replaced with the full port of the
        equivalent view from the legacy <code>index.html</code> /{" "}
        <code>app.js</code> prototype in the next phase.
        {endpoint && (
          <>
            {" "}
            Backend endpoint already available:{" "}
            <code className="rounded bg-muted px-1 py-0.5">{endpoint}</code>.
          </>
        )}
      </CardContent>
    </Card>
  );
}
