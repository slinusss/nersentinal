import { cookies } from "next/headers";
import { me, type SessionUser } from "@/lib/api";

export const SESSION_COOKIE = "ner_session";

/**
 * Reads the bearer token from the httpOnly session cookie set by
 * app/api/session/login/route.ts, and resolves it against the FastAPI
 * backend's /api/me. Returns null when there's no session or the token is
 * no longer valid (expired / user removed / backend restarted).
 *
 * Mirrors the getCurrentProfile() pattern JanReport uses in its route-group
 * layouts, just backed by the FastAPI bearer-token API instead of Supabase.
 */
export async function getCurrentProfile(): Promise<SessionUser | null> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  try {
    return await me(token);
  } catch {
    return null;
  }
}

export async function getSessionToken(): Promise<string | null> {
  const store = await cookies();
  return store.get(SESSION_COOKIE)?.value ?? null;
}
