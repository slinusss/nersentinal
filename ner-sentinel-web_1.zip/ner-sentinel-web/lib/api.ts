// Thin typed client around the NER Sentinel FastAPI backend.
// Base URL is the existing FastAPI service (see backend/app/main.py in the
// NER-Sentinel folder) — this Next.js app is a new frontend for it, the
// backend itself is untouched.

export const API_BASE =
  process.env.NER_SENTINEL_API_BASE ?? "http://127.0.0.1:8000";

export type Role = "citizen" | "official" | "admin";

export interface SessionUser {
  id: string;
  email: string;
  name: string;
  role: Role;
}

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

/**
 * Server-side fetch helper. Pass the bearer token read from the session
 * cookie (see lib/auth.ts) — this file has no knowledge of cookies itself
 * so it works equally from Server Components, Route Handlers, and (if ever
 * needed) the client.
 */
export async function apiFetch<T>(
  path: string,
  options: {
    token?: string | null;
    method?: string;
    body?: unknown;
    cache?: RequestCache;
  } = {}
): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    method: options.method ?? "GET",
    headers: {
      "Content-Type": "application/json",
      ...(options.token ? { Authorization: `Bearer ${options.token}` } : {}),
    },
    body: options.body ? JSON.stringify(options.body) : undefined,
    cache: options.cache ?? "no-store",
  });

  if (!res.ok) {
    let message = res.statusText;
    try {
      const data = await res.json();
      message = data.detail ?? message;
    } catch {
      // response wasn't JSON — keep statusText
    }
    throw new ApiError(message, res.status);
  }

  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

export async function login(
  email: string,
  password: string,
  role: Role
): Promise<{ access_token: string; user: SessionUser }> {
  return apiFetch("/api/auth/login", {
    method: "POST",
    body: { email, password, role },
  });
}

export async function logoutRemote(token: string): Promise<void> {
  await apiFetch("/api/auth/logout", { method: "POST", token });
}

export async function me(token: string): Promise<SessionUser> {
  return apiFetch("/api/me", { token });
}

// --- Domain endpoints used by the pages below -------------------------

export interface DashboardSummary {
  active_incidents: number;
  pending_reports: number;
  road_blockages: number;
  high_risk_corridors: number;
  [key: string]: unknown;
}

export function getDashboard(token: string) {
  return apiFetch<DashboardSummary>("/api/dashboard", { token });
}

export interface RoadSegment {
  id: string;
  name: string;
  state: string;
  district: string;
  latitude: number;
  longitude: number;
  road_condition: string;
  is_blocked: number;
  weather: Record<string, unknown>;
  risk: { score: number; category: string; explanation?: string; factors?: Record<string, number> };
  data_mode: string;
}

export interface Report {
  id: string;
  reporter_name: string;
  assigned_official_name: string | null;
  assigned_official_id: string | null;
  type: string;
  description: string;
  state: string;
  district: string;
  location: string;
  severity: string;
  risk_score: number;
  priority: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  status: string;
  created_at: string;
  updated_at: string;
}

export interface Incident {
  id: string;
  report_id: string;
  type: string;
  state: string;
  district: string;
  location: string;
  road_name: string | null;
  risk_score: number;
  status: string;
  assigned_official_name: string | null;
  verified_at: string;
  notes: string;
}

export interface Notification {
  id: string;
  title: string;
  body: string;
  is_read: number;
  created_at: string;
}

export interface AuditEntry {
  id: string;
  actor_name: string | null;
  action: string;
  entity_type: string;
  entity_id: string;
  details: string | null;
  created_at: string;
}

export interface AnalyticsResponse {
  landslides_by_state: { state: string; count: number }[];
  landslides_by_month: { month: string; count: number }[];
  report_lifecycle: { status: string; count: number }[];
  seasonal_note: string;
}

export interface RouteOption {
  label: string;
  distance_km: number;
  duration_minutes: number;
  risk_level: string;
  avoids_blockage: boolean;
  geometry: [number, number][];
  [key: string]: unknown;
}

export function getMapSegments(token: string) {
  return apiFetch<{ segments: RoadSegment[]; reports: Report[]; incidents: Incident[] }>(
    "/api/map/segments",
    { token }
  );
}

export function getMapConfig() {
  return apiFetch<{ tile_url: string; attribution: string; max_zoom: number }>("/api/map-config");
}

export function getRiskDetail(token: string, segmentId: string) {
  return apiFetch<RoadSegment & { recommended_action: string; historical_events: unknown[]; recent_reports: Report[] }>(
    `/api/risk/${segmentId}`,
    { token }
  );
}

export function getReportsFull(token: string) {
  return apiFetch<{ reports: Report[] }>("/api/reports", { token });
}

export function getIncidentsFull(token: string) {
  return apiFetch<{ incidents: Incident[] }>("/api/incidents", { token });
}

export function getAnalyticsFull(token: string) {
  return apiFetch<AnalyticsResponse>("/api/analytics", { token });
}

export function getAuditFull(token: string) {
  return apiFetch<{ audit: AuditEntry[] }>("/api/audit", { token });
}

export function getNotifications(token: string) {
  return apiFetch<{ notifications: Notification[] }>("/api/notifications", { token });
}

export function getRoutes(
  token: string,
  origin: string,
  destination: string,
  affectedSegmentId?: string
) {
  const qs = new URLSearchParams({ origin, destination });
  if (affectedSegmentId) qs.set("affected_segment_id", affectedSegmentId);
  return apiFetch<{ routes: RouteOption[]; reroute_required: boolean; message: string | null }>(
    `/api/routes?${qs.toString()}`,
    { token }
  );
}

// Known field officials. FastAPI has no GET /api/officials endpoint yet —
// this mirrors the three officials seeded in backend/app/database.py so the
// admin assignment UI has something to pick from. Swap for a real endpoint
// (`GET /api/officials`) in a follow-up backend change.
export interface Investigation {
  id: string;
  report_id: string;
  official_id: string;
  status: string;
  notes: string | null;
  road_condition: string | null;
  outcome: string | null;
  started_at: string | null;
  completed_at: string | null;
}

export interface Evidence {
  id: string;
  filename: string;
  official_name: string;
  notes: string;
  ai_category?: string;
  ai_severity?: string;
  ai_summary?: string;
}

export function getReportDetail(token: string, id: string) {
  return apiFetch<{ report: Report; investigation: Investigation | null; evidence: Evidence[] }>(
    `/api/reports/${id}`,
    { token }
  );
}

export const KNOWN_OFFICIALS = [
  { id: "u-official", name: "Rahul Kharkongor" },
  { id: "u-official-2", name: "P. N. Tashi" },
  { id: "u-official-3", name: "S. Mizo" },
];
