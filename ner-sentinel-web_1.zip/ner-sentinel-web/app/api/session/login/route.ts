import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { login, ApiError, type Role } from "@/lib/api";
import { SESSION_COOKIE } from "@/lib/auth";

export async function POST(request: NextRequest) {
  const body = await request.json();
  const { email, password, role } = body as {
    email: string;
    password: string;
    role: Role;
  };

  try {
    const { access_token, user } = await login(email, password, role);
    const store = await cookies();
    store.set(SESSION_COOKIE, access_token, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      // FastAPI issues short-lived demo tokens; keep the cookie in step so a
      // stale cookie never outlives a token the backend already rejects.
      maxAge: 60 * 60 * 8,
    });
    return NextResponse.json({ user });
  } catch (err) {
    if (err instanceof ApiError) {
      return NextResponse.json({ detail: err.message }, { status: err.status });
    }
    return NextResponse.json(
      { detail: "Could not reach the NER Sentinel API." },
      { status: 502 }
    );
  }
}
