import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { logoutRemote } from "@/lib/api";
import { SESSION_COOKIE } from "@/lib/auth";

export async function POST() {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) {
    try {
      await logoutRemote(token);
    } catch {
      // best-effort: still clear the local cookie even if the backend call fails
    }
  }
  store.delete(SESSION_COOKIE);
  return NextResponse.json({ status: "signed_out" });
}
