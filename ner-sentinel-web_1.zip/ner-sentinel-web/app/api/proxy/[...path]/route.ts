import { NextRequest, NextResponse } from "next/server";
import { API_BASE } from "@/lib/api";
import { getSessionToken } from "@/lib/auth";

// Client components call fetch("/api/proxy/reports/123/assign", ...) instead
// of hitting FastAPI directly, so the bearer token never has to leave the
// httpOnly cookie / server side. This route just forwards the request with
// the Authorization header attached and streams the response back.

async function forward(request: NextRequest, path: string[]) {
  const token = await getSessionToken();
  if (!token) {
    return NextResponse.json({ detail: "Not signed in." }, { status: 401 });
  }

  const target = new URL(`${API_BASE}/api/${path.join("/")}`);
  request.nextUrl.searchParams.forEach((value, key) => target.searchParams.set(key, value));

  const contentType = request.headers.get("content-type") ?? "";
  const init: RequestInit = {
    method: request.method,
    headers: { Authorization: `Bearer ${token}` },
  };

  if (request.method !== "GET" && request.method !== "HEAD") {
    if (contentType.includes("multipart/form-data")) {
      // Pass the FormData straight through (used by the evidence photo upload).
      init.body = await request.formData();
    } else {
      init.headers = { ...init.headers, "Content-Type": "application/json" };
      init.body = await request.text();
    }
  }

  const res = await fetch(target, init);
  const data = await res.text();
  return new NextResponse(data, {
    status: res.status,
    headers: { "Content-Type": res.headers.get("content-type") ?? "application/json" },
  });
}

export async function GET(request: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  return forward(request, (await params).path);
}
export async function POST(request: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  return forward(request, (await params).path);
}
