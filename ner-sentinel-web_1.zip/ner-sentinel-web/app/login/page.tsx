"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import type { Role } from "@/lib/api";

const ROLE_HOME: Record<Role, string> = {
  citizen: "/report",
  official: "/assignments",
  admin: "/dashboard",
};

const DEMO_ACCOUNTS: { role: Role; label: string; email: string }[] = [
  { role: "citizen", label: "Citizen traveller", email: "citizen@nersentinel.in" },
  { role: "official", label: "Field official", email: "officer@nersentinel.in" },
  { role: "admin", label: "NER Control Admin", email: "admin@nersentinel.in" },
];

export default function LoginPage() {
  const router = useRouter();
  const [role, setRole] = useState<Role>("citizen");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent, overrideEmail?: string, overridePassword?: string, overrideRole?: Role) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const finalRole = overrideRole ?? role;
    try {
      const res = await fetch("/api/session/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: overrideEmail ?? email,
          password: overridePassword ?? password,
          role: finalRole,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.detail ?? "Sign in failed.");
        return;
      }
      router.push(ROLE_HOME[finalRole]);
      router.refresh();
    } catch {
      setError("Could not reach the NER Sentinel API.");
    } finally {
      setLoading(false);
    }
  }

  function useDemo(account: (typeof DEMO_ACCOUNTS)[number]) {
    setRole(account.role);
    setEmail(account.email);
    setPassword("Demo@123");
    submit(new Event("submit") as unknown as React.FormEvent, account.email, "Demo@123", account.role);
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-muted/30 px-4 py-10">
      <Card className="w-full max-w-md">
        <CardHeader>
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Secure access
          </p>
          <CardTitle className="text-2xl">Welcome to NER Sentinel</CardTitle>
          <CardDescription>
            Sign in to access the disaster-resilient mobility network.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-3 gap-2">
            {(["citizen", "official", "admin"] as Role[]).map((r) => (
              <button
                key={r}
                type="button"
                onClick={() => setRole(r)}
                className={`rounded-md border px-2 py-1.5 text-sm font-medium capitalize transition-colors ${
                  role === r
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border bg-background text-muted-foreground hover:bg-accent"
                }`}
              >
                {r}
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="email">Email address</Label>
              <Input
                id="email"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            {error && (
              <p role="alert" className="text-sm text-destructive">
                {error}
              </p>
            )}
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Signing in…" : "Sign in securely →"}
            </Button>
          </form>

          <div className="space-y-2 border-t border-border pt-4">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Demo access · select an account
            </p>
            {DEMO_ACCOUNTS.map((account) => (
              <button
                key={account.role}
                type="button"
                onClick={() => useDemo(account)}
                disabled={loading}
                className="flex w-full items-center justify-between rounded-md border border-border px-3 py-2 text-left text-sm hover:bg-accent"
              >
                <span>
                  <b className="block">{account.label}</b>
                  <span className="text-xs text-muted-foreground">{account.email}</span>
                </span>
                <span>→</span>
              </button>
            ))}
          </div>
          <p className="text-center text-xs text-muted-foreground">
            This prototype uses simulated data only. No live emergency response
            decisions should rely on it.
          </p>
        </CardContent>
      </Card>
    </main>
  );
}
