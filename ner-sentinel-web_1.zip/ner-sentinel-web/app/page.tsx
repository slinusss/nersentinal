import { redirect } from "next/navigation";
import { getCurrentProfile } from "@/lib/auth";

const ROLE_HOME: Record<string, string> = {
  citizen: "/report",
  official: "/assignments",
  admin: "/dashboard",
};

export default async function Home() {
  const profile = await getCurrentProfile();
  redirect(profile ? ROLE_HOME[profile.role] ?? "/login" : "/login");
}
